package com.example.francescocontu.esercitazionebonus;

import java.io.Serializable;

public class AccessInfo implements Serializable {

    private String username;
    private boolean acss;

    public AccessInfo(){

        this.username = "";
        this.acss = false;

    }

    public AccessInfo(String username, boolean acss){

        this.username = username;
        this.acss = acss;

    }

    public String getUsername() { return username; }
    public boolean isAcss() { return acss; }

}
