package com.example.francescocontu.esercitazionebonus;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ShowResultActivity extends AppCompatActivity {

    TextView label;
    Button backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_result);

        Intent intent = getIntent();
        label = (TextView) findViewById(R.id.label);
        backBtn = (Button) findViewById(R.id.backBtn);

        Object o = intent.getSerializableExtra(MainActivity.ACCESSINFO_EXTRA);
        AccessInfo ai;

        if(o.getClass().equals(AccessInfo.class)){

            ai = (AccessInfo) o;

            if(ai.isAcss()){

                label.setText("Benvenuto/a " + ai.getUsername());

            }
            else{

                label.setText("Accesso negato!");
                label.setTextColor(Color.RED);

            }

        }
        else{

            label.setText("Accesso negato!");
            label.setTextColor(Color.RED);

        }

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ShowResultActivity.this, MainActivity.class);
                startActivity(intent);

            }
        });



    }
}
