package com.example.francescocontu.esercitazionebonus;

import android.content.Intent;
import android.support.annotation.IntDef;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static String ACCESSINFO_EXTRA = "com.example.francescocontu.esercitazionebonus";

    private EditText passTxt, userTxt;
    private TextView errorMsg;
    private Button logIn;

    private User user;
    private String str;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        errorMsg = (TextView) findViewById(R.id.errorMsg);
        userTxt = (EditText) findViewById(R.id.userTxt);
        passTxt = (EditText) findViewById(R.id.passTxt);
        logIn = (Button) findViewById(R.id.logIn);

        logIn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(checkInput(userTxt, passTxt)) {

                    errorMsg.setVisibility(View.INVISIBLE);
                    Intent intent = new Intent(MainActivity.this, ShowResultActivity.class);
                    List<User> uList = loadUserList();
                    updateUser();
                    intent.putExtra(ACCESSINFO_EXTRA, new AccessInfo(user.getUsername(), uList.contains(user)));
                    startActivity(intent);

                }
                else{

                    errorMsg.setVisibility(View.VISIBLE);

                }
            }

        });


    }

    private static boolean checkInput(EditText userTxt, EditText passTxt){

        if((userTxt == null || userTxt.length() == 0) || (passTxt == null || passTxt.length() == 0)){

            return false;

        }
        else{

            return true;

        }

    }

    private void updateUser(){

        user = new User(userTxt.getText().toString(), passTxt.getText().toString());

    }

    private static List<User> loadUserList(){

        List<User> uList = new ArrayList<>();

        uList.add(new User("Marco","1234"));
        uList.add(new User("Marta","5678"));

        return uList;

    }
}
