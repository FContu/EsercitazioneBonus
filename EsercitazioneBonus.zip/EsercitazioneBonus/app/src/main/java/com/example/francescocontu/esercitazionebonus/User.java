package com.example.francescocontu.esercitazionebonus;

public class User {

    private String username;
    private String password;

    public User(){

        this.username = "";
        this.password = "";

    }

    public User(String username, String password){

        this.username = username;
        this.password = password;

    }

    @Override
    public boolean equals(Object o){

        if(o.getClass().equals(this.getClass())){

            if(((User)o).getUsername().equals(this.getUsername()) && ((User)o).getPassword().equals(this.getPassword())) {

                return true;

            }
            else{

                return false;

            }

        }
        else{

            return false;

        }

    }

    public String getPassword() { return password; }
    public String getUsername() { return username; }

    public void setPassword(String password) { this.password = password; }
    public void setUsername(String username) { this.username = username; }

}
